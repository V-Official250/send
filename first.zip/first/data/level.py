import pygame,random

class Level:
    def __init__(self):
        self.speed = 1
        self.rectlist = [pygame.Rect(400,0,120,300),pygame.Rect(450,350,120,300)]
        self.walls = [self.rectlist[0]]

    def update(self,dt,player,window):
        if player.died == False:
            for rect in self.walls:
                if player.rect.colliderect(rect):
                    player.died = True

            self.speed += self.speed/500 * dt

            for rect in self.walls:
                rect.x -= self.speed * dt
                pygame.draw.rect(window.window,(0,255,0),rect)
                if -120 > rect.x:
                    self.walls = []
                    sameple = random.choices(self.rectlist)[0]
                    sameple.x = 400
                    self.walls.append(sameple)
        else:
            self.speed = 1
            self.rectlist = [pygame.Rect(400,0,120,300),pygame.Rect(450,350,120,300)]
            self.walls = [self.rectlist[0]]